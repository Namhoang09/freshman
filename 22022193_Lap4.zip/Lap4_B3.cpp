#include <stdio.h>

int main() {
	int L;
	scanf("%d", &L);
	int Flag;
	scanf("%d", &Flag);
	int delay=0;
	switch(L) {
		case 1: delay+=14; break;
		case 2: delay+=7; break;
		case 3: delay+=9;
	}
	if(Flag==0) {
		printf("%d", 2*delay);
	}
	else {
		printf("%d", delay);
    }
}
