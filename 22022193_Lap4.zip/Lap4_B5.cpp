#include <stdio.h>
#include <math.h>
int main() {
	int a;
	// a*a - 3*a = 0
	int denta = (-3) * (-3) - 4 * 1 * 0;
	a = (3 - sqrt(denta)) / 2;
	if(a>0) {
		printf("%d %d %d", 2*a, a, 2*a*a);
	}
	else if(a<=0) {
		a = (3 + sqrt(denta)) / 2;
		printf("%d %d %d", 2*a, a, 2*a*a);
	}
}
