#include <stdio.h>

int main() {
	int L;
	scanf("%d", &L);
	int bandwidth=0, delay=0;
	switch(L) {
		case 1:
			bandwidth +=9; delay +=14;
			break;
		case 2:
			bandwidth +=4; delay +=7;
			break;
		case 3:
			bandwidth +=9; delay +=9;
			break;
	}
	int cost = 2*bandwidth+delay;
	int A = cost;
	printf("%d\n", cost);
	if(L==2) {
		for(int i=0; i<19; i++) {
			cost+= A;
		}
	}
	else if(L==1) {
		int j=0;
		while(j<9) {
			cost += A;
			j++;
		}
	}
	printf("%d", cost);
}
