#include <stdio.h>

int main() {
	int bandwidth, delay;
	int tuyen;
	scanf("%d", &tuyen);
	switch(tuyen) {
		case 1:
			bandwidth = 9; delay = 14;
			break;
		case 2:
			bandwidth = 7; delay = 10;
			break;
		case 3:
			bandwidth = 4; delay = 7;
			break;
		case 4:
			bandwidth = 7; delay =8;
			break;
		case 5:
			bandwidth = 9; delay = 9;
			break;
	}
	int cost = 2*bandwidth + delay;
	printf("%d\n", cost);
	
}
