#include <stdio.h> 

int main() {
	printf("San pham tot               San pham hong\n");
	for(int i=0; i<100; i++) {
		if(i%10!=0) {
			printf("%7d\n", i+1);
			continue;
		}
	}
	for(int i=0; i<100; i++) {
		if(i%10==0) {
			printf("%30d\n", i+1);
			continue;
		}
	}
}
