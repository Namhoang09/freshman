#include <stdio.h> 
#include <stdlib.h>
#include <time.h>
#include <math.h>
float random(float min, float max) {
	float A = rand()/(float) RAND_MAX;
	return min + A*(max-min);
}
int main() {
	srand((int)time(0));
	float a[12];
	for(int i=0; i<12; i++) {
		a[i]=random(0,500);
	}
	for(int i=0; i<12; i++) {
		printf("%.2f\n", a[i]);
	}
	float sum1;
	float u;
	for(int i=0; i<12; i++) {
		sum1 += a[i];
	}
	u = sum1/12;
	float o;
	float sum2;
	for(int i=0; i<12; i++) {
		sum2 += (a[i]-u) * (a[i]-u);
	}
	o = sum2/12;
	printf("Ky vong toan: %.2f\nDo lech chuan: %.2f", u, sqrt(o));
}
