#include <stdio.h>
#include <stdlib.h>
#include <time.h>
float random(float min, float max) {
	float A = rand()/ (float) RAND_MAX;
	return min + A * (max-min);
}
int main() {
	// Lay 1 so ngau nhien
    srand((int)time(0));
	float a = random(0,10);
	printf("%lf\n",a);
	float b = a - (int)a;
	int c;
	// lam tron so
	if(b<0.5) {
		c = (int)a;
	}	
	else {
		c = (int)a + 1;
	}
	printf("%d\n", c);
	// chuyen ve nhi phan
	int arr[8];
	int i=0;
	int x;
	while(c!=0) {
		arr[i]=c%2;
		c/=2;
		i++;
		x=i;
	}
	for(int j=x-1; j>=0; j--) {
		printf("%d", arr[j]);
	}
	// dem so bit 0 va 1
	int d[8] = {2,2,2,2,2,2,2,2} , e[8] = {2,2,2,2,2,2,2,2};
	int count0=0, count1=0;
	for(int j=0; j<x; j++) {
		if(arr[j]==0) {
			count0++;
			d[j]=0;
		}
		else if(arr[j]==1) {
		    count1++;
		    e[j]=1;
		}
	}
	printf("\nSo bit 1: %d\nSo bit 0: %d\n", count1,count0);
	printf("Ti le bit 1 so voi bit 0: %.2f\nTi le bit 1 so voi tong so bit: %.2f\n", (double) count1/count0, (double)count1/x);
	// chuyen bit 0 va 1 ra mang rieng
	for(int i=0; i<8; i++) {
		if(d[i]==0) printf("%d", d[i]);
	}
	printf("\n");
	for(int i=0; i<8; i++) {
		if(e[i]==1) printf("%d", e[i]);
	}
}
