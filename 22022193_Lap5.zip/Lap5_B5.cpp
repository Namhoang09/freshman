#include <stdio.h>

int main() {
	int n;
	scanf("%d", &n);
	int a[n][n];
	for(int i=0; i<n; i++) {
		for(int j=0; j<n; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for(int i=0; i<n; i++) {
		for(int j=0; j<n; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	int b[n][n];
	for(int i=0; i<n; i++) {
		for(int j=0; j<n; j++) {
			b[j][i]=a[i][j];
		}
	}
	for(int i=0; i<n; i++) {
		for(int j=0; j<n; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	int count=0;
	for(int i=0; i<n; i++) {
		for(int j=0; j<n; j++) {
			if(b[i][j]==b[j][i]) {
				count++;
			}
		}
    }  
    if(count==n*n) printf("Ma tran doi xung\n");
    else printf("Ma tran ko doi xung\n");
    int sum1=0,sum2=0;
    for(int i=0; i<n; i++) {
		for(int j=0; j<n; j++) {
			if(i==j) sum1+=a[i][j];
		}
    }
    for(int i=0; i<n; i++) {
		for(int j=0; j<n; j++) {
			if(i==n-1-j) sum2+=a[i][j];
		}
    }
    printf("%d %d", sum1,sum2);
}
