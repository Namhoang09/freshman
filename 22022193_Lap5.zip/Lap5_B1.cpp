#include <stdio.h>
#include <stdlib.h>
#include <time.h>
float random(float min, float max) {
	float A = rand()/ (float) RAND_MAX; 
	return min + A*(max-min);
}
int main() {
	srand((int)time(0));
	int i;
	float a[80];
	for(i=0; i<80; i++) {
		a[i] = random(0,10);
	}
	for(int i=0; i<80; i++) {
		printf("%.2f\n", a[i]);
	}
	float MAX = a[0];
	float MIN = a[79];
	for(int i=0; i<80; i++) {
		if(a[i] > MAX) {
			MAX = a[i];
	    }
    } 
    for(int i=0; i<80; i++) {
    	if(a[i] < MIN) {
    		MIN = a[i];
		}
	}
	printf("Diem lon nhat: %.2f\nDiem nho nhat: %.2f\n", MAX,MIN);
	float sum;
	int count=0;
	for(int i=0; i<80; i++) {
		if(a[i]>=6.5) {
			sum+=a[i];
		}
	}
	for(int i=0; i<80; i++) {
		if(a[i]>=9.0) {
			count++;
		}
	}
	printf("Tong diem tu C+ la: %.2f\nSo diem A+ la: %d",sum,count);
}
