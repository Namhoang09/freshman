#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int random(int min, int max) {
	return min + rand()%(max+1-min);
}
int main() {
	int a[8][8];
	srand((int)time(0));
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			a[i][j] = random(0,1);
		}
	}
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	int b[8][8], c[8][8];
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			b[i][j]=1;
			if(j>=i) c[i][j]=1;
			else c[i][j]=0;
		}
	}
	int d[8][8],e[8][8];
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			int tt = 0;
			for(int k=0; k<8; k++) {
				tt += a[i][k]*b[k][j];
			}
			e[i][j]=tt;
		}
	}
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			if(c[i][j]>=1 && e[i][j]>=1) d[i][j]=1;
		    else d[i][j]=0;
		}
	}
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			printf("%d ", d[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	int count=0;
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			if(i==j) printf("%d ", d[i][j]);
		}
	}
	printf("\n");
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			if(i==7-j) printf("%d ", d[i][j]);
		}
	}
	printf("\n");
	printf("\n");
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			if(i<j) d[i][j]=0;
		}
	}
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			printf("%d ", d[i][j]);
		}
		printf("\n");
	}
	for(int i=0; i<8; i++) {
		for(int j=0; j<8; j++) {
			if(i==j && d[i][j]==1) count++;
		}
	}
	printf("%d", count);
}
