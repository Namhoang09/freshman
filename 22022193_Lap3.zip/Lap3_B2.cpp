#include "graphics.h"
#pragma comment(lib, "graphics.lib")
#include<stdio.h>

void ve_duong_thang(double x1,double y1, double x2, double y2){
	if (x1 - x2==0) {
		for (int i = y1; i <= y2; i++) {
			putpixel(x1, i, WHITE);
		}
	}
	else if (y1 == y2) {
		for (int i = x1; i <= x2; i++) {
			putpixel(i, y1, WHITE);
		}
	}
	else {
		double a = (y2 - y1) / (x2 - x1);
		for (int i = x1; i <= x2; i++) {
			putpixel(i, a * i + y1-a*x1, WHITE);
		}
	}	
}
int main()
{
	initwindow(800, 800);
	ve_duong_thang(1,1 , 300, 500);
	line(1, 1, 300, 500);
	delay(5000);
	
}
