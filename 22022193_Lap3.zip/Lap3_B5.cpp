#include "graphics.h"
#pragma comment(lib, "graphics.lib")
#include<stdio.h>
#include<math.h>


int main() {
	initwindow(600, 600);
	for (float i=0; i <=800; i++) {
		float y = 40*sin(i * 3.14 / 180);
		putpixel(i, y+300, RED);
		
	}
	for (float i = 0; i <= 800; i++) {
		float y = 60 * sin(i * 3.14 / 180);
		putpixel(y + 300,i, RED);

	}
	for (float i = 0; i <= 800; i++) {
		float y =-60 * sin(i * 3.14 / 180);
		putpixel(y + 300, i, GREEN);

	}

	getch();
	return 0;

}

