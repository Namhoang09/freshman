#include "graphics.h"
#pragma comment(lib, "graphics.lib")
#include<stdio.h>

void somg_song(double x1, double y1, double x2, double y2) {
	if (x1 - x2 == 0) {
		for (int i = y1; i <= y2; i++) {
			putpixel(x1+1, i, WHITE);
		}
	}
	else if (y1 == y2) {
		for (int i = x1; i <= x2; i++) {
			putpixel(i, y1+1, WHITE);
		}
	}
	else {
		double a = (y2 - y1) / (x2 - x1);
		for (int i = x1; i <= x2; i++) {
			putpixel(i, a * i + y1 - a * x1+1, WHITE);
		}
	}
}
void nhap_so(double* a,int n) {
	for (int i=0; i < n; i++) {
		scanf("%lf", &a[i]);
	}
}

int main(){
	double a[4];
	nhap_so(a, 4);
    delay(7000);
	initwindow(800, 800);
	line(a[0], a[1], a[2], a[3]);
	delay(5000);
}
