#include "graphics.h"
#pragma comment(lib, "graphics.lib")
#include<stdio.h>

int main()
{
    initwindow(800, 800);
    setfillstyle(1, 11);
    fillellipse(400, 400, 300, 200);
    setfillstyle(1, RED);
    bar(600,500 , 200, 300);
    setfillstyle(1, GREEN);
    fillellipse(400, 400, 100, 100);
    
    getch();
    return 0;
}
