#include "graphics.h"
#pragma comment(lib, "graphics.lib")
#include<stdio.h>

void lap(int x, int y, char* s) {
    for (int i = 0; i <= 15; i++) {
        setcolor(i); putpixel(x-2, y-1 + 40 * i, i);
        outtextxy(x,y + 40 * i, s);
    }
}


int main()
{
    initwindow(800, 800);
    char s[] = "Xin chao thu mau k";
    settextstyle(0, 0, 2);
    lap(250, 40, s);
    setfillstyle(1, GREEN);
    bar(140, 0, 248, 800);
    setfillstyle(1, 11);
    bar(502, 0, 620, 800);
    getch();
    return 0;
    
}
