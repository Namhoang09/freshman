#include <stdio.h>
#include <math.h>
int main() {
	int x;
	scanf("%d", &x);
	int arr[100];
	int i=0;
	int a;
	while(x!=0) {
		arr[i]=x%10;
		x/=10;
		i++;
		a=i;
	}
	int sum=0;
	int j;
	for(j=0; j<a; j++) {
		sum += arr[j] * pow(2,j);
	}
	printf("%d", sum);
}
