#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int random(int min, int max) {
 return min + rand() % (max + 1 - min);
}
int main() {
	int a,b;
	scanf("%d%d", &a, &b);
    srand((int)time(0));
    int x[100],t=0; 
    int i;
    for(i=0; i<100; i++) {
        x[i] = random(a,b);
        printf("%d\n", x[i]);
        t += sizeof(x[i]);
    }  
/*	for(i=0; i<100;i++) {
		int k=0, n=x[i], a[100];
		while (n!=0) {
		   a[k]=n%2;
		   n/=2;
		   k++;	   
	    }
	    a[k]=n;
	    int j;
	    for(j=k;j>=0;j--){
		printf("%d\n", a[j]);
	    }
	}
*/	 
	printf("%d",t);
}
