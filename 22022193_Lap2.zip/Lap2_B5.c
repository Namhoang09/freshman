#include <stdio.h>
#include <stdlib.h>
#include <time.h>
float random(float min, float max) {
	float A = rand()/ (float) RAND_MAX; 
	return min + A*(max-min);
}
int main() {
	srand((int)time(0));
	float a,b;
	int i;
	for(i=0; i<2; i++) {
		a = random(0,1);
		b = random(0,1);
	}
	printf("%lf %lf\n", a,b);
	if(0<a && a<0.5) a=0;
	else a=1;
	if(0<b && b<0.5) b=0;
	else b=1;
	printf("%lf %lf", a,b);
}
