#include <stdio.h>
#include <stdlib.h>
#include <time.h>
float random(float min, float max) {
	return min + rand()*(max-min)/(1.0*RAND_MAX);
}
int main () {
	srand((int)time(0));
	int i;
	float x,n;
	for(i=0; i<1; i++) {
		x = random(-3,3);
		n = random(0,1);
	}
	float y = x+n;
	if(y>=0) {
	    if(y - (int)y < 0.5) y = (int)y;
	    else y = (int)y + 1;
	}
	else {
		if(y - (int)y < -0.5) y = (int)y - 1;
		else y = (int)y;
	}
	printf("%lf %lf\n", x,n);
	printf("%7.2f", y);
}
