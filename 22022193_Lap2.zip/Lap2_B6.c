#include <stdio.h>
#include <stdlib.h>
#include <time.h>
float random(float min, float max) {
	return min + rand()*(max-min)/(1.0*RAND_MAX);
}
int main () {
	float a,b;
	scanf("%f%f", &a,&b);
	srand((int)time(0));
	int i;
	float x;
	for(i=0; i<1; i++) {
		x = random(a,b);
	}
	printf("%lf\n", x);
	printf("%.1f0\n", x);
	printf("%.2f0\n", x);
	printf("%.2e", x/1000000);
}
