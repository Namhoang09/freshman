#include <stdio.h>
int main() {
	int a;
	scanf("%d", &a);
	int arr[100];
	int i=0;
	int x;
	while(a!=0) {
		arr[i]=a%2;
		a/=2;
		i++;
		x=i;
	}
	int j;
	for(j=x-1; j>=0; j--) {
		printf("%d", arr[j]);
	}
}
