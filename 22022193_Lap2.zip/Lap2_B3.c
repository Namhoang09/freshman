/* #include <stdio.h>
#include <stdlib.h>
int main() {
	int n;
	for(int i=0; i<5; i++) {
		printf("%d ", rand());
	}
} */


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
	srand((int)time(0));
	int i;
	for(i=0; i<5; i++) {
		printf("%d ", rand());
	}
}
