#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main() {
	FILE *fp, *fp1;
	fp = fopen("SinhVien.txt","r");  //mo file
	if(fp == NULL) {
		printf("Khong the mo file SinhVien.txt");
		return 1;
	}
	fp1 = fopen("SinhVien-Copy.txt","w");
	if(fp1 == NULL) {
		printf("Khong the mo file SinhVien-Copy.txt");
		fclose(fp);
		return 1;
	}
	char x;
	while(x != EOF) {
		x = fgetc(fp); //Doc trong file
		if(x != EOF) {
			fputc(x,fp1); //Ghi vao file copy
		}
	}
	fclose(fp);
	fclose(fp1);
	printf("Copy xong\n");
	FILE *file;  //Doc va in ra
	file = fopen("SinhVien-Copy.txt","r");
	printf("Ten:\t\tMSV:\t\t\tDiem:\n");
	char Ten[50];  
	int MSV;
	float Diem;
	while(fscanf(file,"Ten: %s\t\tMSV: %d\t\t\tDiem: %f\n", Ten, &MSV, &Diem) != EOF) {
		printf("%s\t\t%d\t\t%.1f\n", Ten, MSV, Diem);
	}
	fclose(file);
}
