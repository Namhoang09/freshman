#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main() {
	// Nhap Input
	FILE *f;
	f = fopen("Input1.txt","w");
	int a[10][10];
	for(int i=0; i<3; i++) {
		for(int j=0; j<3; j++) {
			scanf("%d", &a[i][j]);
		}
	}
	for(int i=0; i<3; i++) {
		for(int j=0; j<3; j++) {
			fprintf(f,"%d ", a[i][j]);
		}
		fprintf(f,"\n");
	}
	FILE *f1;
	f1 = fopen("Input2.txt","w");
	int b[10][10];
	for(int i=0; i<3; i++) {
		for(int j=0; j<4; j++) {
			scanf("%d", &b[i][j]);
		}
	}
	fprintf(f1,"3\n");
	fprintf(f1,"4\n");
	for(int i=0; i<3; i++) {
		for(int j=0; j<4; j++) {
			fprintf(f1,"%d ", b[i][j]);
		}
		fprintf(f1,"\n");
	}
	printf("Nhap xong\n");
	fclose(f);
	fclose(f1);
	// In ra
	f = fopen("Input1.txt","r");
	f1 = fopen("Input2.txt","r");
	printf("Ma tran 3x3 la:\n");
	for(int i=0; i<3; i++) {
		for(int j=0; j<3; j++) {
			fscanf(f,"%d",&a[i][j]);
		}
	}
	for(int i=0; i<3; i++) {
		for(int j=0; j<3; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
	int num1,num2;
	fscanf(f1,"%d", &num1);
	fscanf(f1,"%d", &num2);
	printf("Ma tran 3x4 la:\n");
	for(int i=0; i<3; i++) {
		for(int j=0; j<4; j++) {
			fscanf(f1,"%d",&b[i][j]);
		}
	}
	for(int i=0; i<3; i++) {
		for(int j=0; j<4; j++) {
			printf("%d ", b[i][j]);
		}
		printf("\n");
	}
	fclose(f);
	fclose(f1);
	// Sao chep
	f = fopen("Input1.txt","r");
	f1 = fopen("Input2.txt","r");
	FILE *f2;
	f2 = fopen("Output.txt","w");
	char x;
	while(x != EOF) {
		x = fgetc(f);
		if(x != EOF) {
			fputc(x, f2);
		}
	}
	fclose(f);
	char y;
	while(y != EOF) {
		y = fgetc(f1);
		if(y != EOF) {
			fputc(y, f2);
		}
	}
	fclose(f1);
	fclose(f2);
	printf("Copy xong");
}
