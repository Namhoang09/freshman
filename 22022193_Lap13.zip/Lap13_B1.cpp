#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
struct soPhuc {
	float x;
	float y;
};
typedef soPhuc sp;
void Nhap(sp *a) {
	printf("Phan thuc: ");
	scanf("%f", &a->x);
	printf("Phan ao: ");
	scanf("%f", &a->y);
}
void Xuat(sp a) {
	if(a.y==0 && a.x==0) printf("So phuc la: 0\n");
	else if(a.y==0 && a.x!=0) printf("So phuc la: %.2f\n", a.x);
	else if(a.y!=0) printf("So phuc la: %.2f+%.2fi\n", a.x, a.y);
}
soPhuc Tong(sp a,sp b) {
	sp c;
	c.x = a.x + b.x;
	c.y = a.y + b.y;
	return c;
}
soPhuc Hieu(sp a,sp b) {
	sp c;
	c.x = a.x - b.x;
	c.y = a.y - b.y;
	return c;
}
soPhuc Tich(sp a,sp b) {
	sp c;
	c.x = a.x * b.x - a.y * b.y;
	c.y = a.x * b.y + a.y * b.x;
	return c;
}
soPhuc Thuong(sp a,sp b) {
	sp c;
	c.x = (a.x * b.x + a.y * b.y) / (b.x * b.x + b.y * b.y);
	c.y = (a.y * b.x - a.x * b.y) / (b.x * b.x + b.y * b.y);
	return c;
}
float Argument(sp a) {
	return atan(a.y/a.x);
}
float Mudul(sp a) {
	return sqrt(a.x * a.x + a.y * a.y);
}
int main() {
	soPhuc a,b;
	Nhap(&a);
	Xuat(a);
	Nhap(&b);
	Xuat(b);
	printf("\nTong 2 so phuc: ");
	Xuat(Tong(a,b));
	Xuat(a); Xuat(b);
	printf("\nHieu 2 so phuc: ");
	Xuat(Hieu(a,b));
	Xuat(a); Xuat(b);
	printf("\nTich 2 so phuc: ");
	Xuat(Tich(a,b));
	Xuat(a); Xuat(b);
	printf("\nThuong 2 so phuc: ");
	Xuat(Thuong(a,b));
	Xuat(a); Xuat(b);
	printf("\nArgument 2 so phuc: %.2f\n", Argument(a));
	Xuat(a);
	printf("\nMudul 2 so phuc: %.2f\n", Mudul(a));
	Xuat(a);
}
