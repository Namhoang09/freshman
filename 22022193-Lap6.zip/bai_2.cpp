#include<stdio.h>
#include<stdlib.h>

int tim_kiem(int*a,int n,int x){
	int r= n -1,l=0; 
	while (r>= l){
		int mid=l+(r-l)/2;
		if(a[mid]== x) return 1;
		else if(a[mid]> x) r=mid-1;
		else l=mid+1;	    	
	}
	return 0;
} 

int main(){
	int n;
	printf("Nhap cap cua ma tran vuong: ");
	scanf("%d", &n);
	
	int m=n*n;
	int* a=(int *) malloc(m*sizeof(int));
	for(int i=0;i<m;i++){
		scanf("%d", &a[i]);
	}
	
	int t=0,x;
	for(int i=0;i<m;i++){
		if(i==(n+1)*t) a[i]=1;
		if((i+1)%n==0) t++;
	}
	printf("Ma tran ma PC2 nhan duoc:\n");
	for(int i=0;i<m;i++){
		printf("%d ", a[i]);
		if((i+1)%n==0) printf("\n");
	}
	for(int i=0;i<m;i++){
		for(int j=0;j<m;j++){
			if(a[i]<a[j]){
				int h=a[j];
				a[j]=a[i];
				a[i]=h;
			}
		}
	}
    printf("Ma tran ma PC2 sau khi sap xep:\n");
	for(int i=0;i<m;i++){
		printf("%d ", a[i]);
		if((i+1)%n==0) printf("\n");
    }
    printf("Nhap so can tim: ");
    scanf("%d", &x);
    if(tim_kiem(a, m,x)==1) printf("Phan tu %d co trong ma tran", x);
    else printf("Phan tu %d khong co trong ma tran", x);
    
     printf("\nThoi gian ma tran a gui tu PC1--> PC2 theo tuyen 3: %.4lfs", m*sizeof(a[0])/16000.0); 
    
}
