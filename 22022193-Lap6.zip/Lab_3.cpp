#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int doi_xung(char*a){
	for(int i=0;i<strlen(a)/2;i++){
		if(a[i]!=a[strlen(a)-1-i]) return 0;
	}
	return 1;
} 

int main(){
	char*a=(char*)malloc(1000*sizeof(char));
	fgets(a, 1000,stdin);
	printf("%s", a);
	if(doi_xung(a)==0) printf("Buc thu khong doi xung.\n");
	else printf("Buc thu doi xung.\n");
	 
	int h=strlen(a);
	char*c=(char*)malloc(1000*sizeof(char));
	strcpy(c,a);
	strlwr(c);
	for(int i=0;i<h;i++){
		if((c[i]>64&& c[i]<91)||(c[i]>96&&c[i]<123)){
			int t=0;
		    for(int j=0;j<h;j++){
			     if(c[i]==c[j]){
			     	if(i>j) break;
					 else t++; 
				 }			
		    } 	
			if(t>1) printf("ki tu %c co %d ki tu giong nhau.\n", c[i],t);	         
	    }  
   }
   
   char n; int t=0 ; 
   printf("Nhap ki tu can tim: ");
   scanf("%c", &n);
   for(int i=0;i<h;i++){
   	   if(n==a[i]) t++; 
   } 
   printf("Co %d xuat hien ki tu %c\n", t,n) ;
   
   printf("Buc thu ma PC2 nhan duoc bi loi theo kieu 1:");
   for(int i=h-1;i>=0;i--){
   	    printf("%c",a[i]); 
   }
    
   printf("\nBuc thu ma PC2 nhan duoc bi loi theo kieu 2:\n");
   for(int i=h-1;i>=0;i--){
		int k=0;
		if(a[i]==' '|| i==0){

			k=1;
		for(int j=i;j<h;j++){
			if(a[j]!=' ' && a[j]!='\n')printf("%c",a[j]);
		}
	} 
	
        if(k!=0){
	        printf(" ");
	        a[i]=NULL;
            h=i;} 
    }
    printf("\nThoi gian ma buc thu gui tu PC1 den PC2 theo tuyen 1: %lfs", (float)sizeof(a)/32000);
}

