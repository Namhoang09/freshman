#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int main(){
	char* a=(char*) malloc(60*sizeof(char));
	a[0]='9';a[1]='x';a[2]='1';a[3]='=';a[4]='9';
	a[55]='1';a[56]='0';a[57]='=';a[58]='9';a[59]='0';
	for(int i=0;i<60;i++){
		if(i>4&&i<55){
			if((i+1)%6==0) a[i]='9';
		    if(i%6==0) a[i]='x';
		    if((i-2)%6==0) a[i]='=';
		    if((i-1)%6==0) a[i]='1'+(i-1)/6;
		    if((i-3)%6==0){
		    	a[i]='0'+(i-3)/6;
		    	a[i+1]='9'-(i-3)/6;
			}
		}
	}
    for(int i=0;i<60;i++){
    	printf("%c", a[i]);
    	if((i==4||(i-4)%6==0)&&i<55) printf("\n");
    	else if(((i-3)%6==0&&i<55&& i>6)||i==55||i==58) ;
    	else printf(" ");
	}
	 printf("\nBCC --> Chuoi nhi phan:\n");
	 int* c=(int*)malloc(480*sizeof(int)),m=0;
 	 for(int i=0;i<60;i++){
		 int h=0, k=(int)a[i];
 	 	 int b[8];
	 	 while(k!=0){
		    b[h]=k%2;
		    h++;
		    k/=2;
	     }
	     
	     for(int j=h;j<8;j++){
	     	b[j]=0;      	
		 }
		 
		 for(int j=0;j<4;j++){
	        	int t=b[j];
	        	b[j]=b[7-j];
	        	b[7-j]=t;
			}
	      
		 for(int j=0;j<8;j++){
	  	 	c[m]=b[j];
			m++; 
      	 }
      } 
      for(int i=0;i<480;i++){
      	printf("%d", c[i]);
      }
      
      printf("\nThoi gian di theo tuyen 1: %.4lfs. ",480.0/32000);
      printf("Thoi gian di theo tuyen 2: %.4lfs. ",480.0/64000);
      printf("Thoi gian di theo tuyen 3: %.4lfs.\n",480.0/16000);
      
	   
      int s=0,r=0;
      for(int i=0;i<480;i++){
      	if(c[i]==1) s++;
	  }
	  printf("Co %d bit so 1 cua chuoi truoc khi gui. ", s);
	  if(c[0]==0) c[0]=1;
	  else c[0]=0;
	  if(c[479]==0) c[479]=1;
	  else c[479]=0;
      for(int i=0;i<480;i++){
      	if(c[i]==1) r++;
	  }
	  printf("Co %d bit so 1 cua chuoi sau khi gui. BCC ma PC2 nhan duoc sau khi loi la:\n", r);
	  
	  int n=0;
	  for(int i=0;i<=59;i++){
	  	    int q=0;
	  	    if(i>0) n=n+8;
	  	    for(int j=n;j<=n+7;j++){
		         q+=pow(2,(n+7-j))*c[j];    
	        }
	        printf("%c", q);
	        if((i==4||(i-4)%6==0)&&i<55) printf("\n");
    	    else if(((i-3)%6==0&&i<55&& i>6)||i==55||i==58) ;
    	    else printf(" ");  
	  }
} 
