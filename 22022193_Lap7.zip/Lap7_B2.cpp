#include <stdio.h>
#include <stdlib.h>
void nhapMang(int **a, int dong, int cot) {
	for(int i=0; i<dong; i++) {
		for(int j=0; j<cot; j++) {
			scanf("%d", &a[i][j]);
		}
	}
}
void xuatMang(int **a, int dong, int cot) {
	for(int i=0; i<dong; i++) {
		for(int j=0; j<cot; j++) {
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
}
int main() {
	int dong, cot;
	scanf("%d %d", &dong,&cot);
	int **a;
	a = (int**)malloc(dong* sizeof(int*));
	for(int i=0; i<dong; i++) {
		a[i] = (int*)malloc(cot* sizeof(int));
	}
	nhapMang(a,dong,cot);
	printf("Ma tran A:\n");
	xuatMang(a,dong,cot);
	int **b;
	b = (int**)malloc(dong* sizeof(int*));
	for(int i=0; i<dong; i++) {
		b[i] = (int*)malloc(cot* sizeof(int));
	}
	for(int i=0; i<dong; i++) {
		for(int j=0; j<cot; j++) {
			b[i][j]=0;
		}
	}
	for(int i=0; i<dong; i++) {
		for(int j=0; j<cot; j++) {
			for(int k=0; k<=j; k++) {
				b[i][j]+=a[i][k];
			}
		}
	}
	printf("Ma tran B:\n");
	xuatMang(b,dong,cot);
	int max=b[0][0];
	for(int i=0; i<dong; i++) {
		for(int j=0; j<cot; j++) {
			if(b[i][j]>max) max=b[i][j];
		}
	}
	printf("Gia tri lon nhat cua B: %d\n", max);
	printf("Ma tran C:\n");
	int **c;
	c = (int**)malloc(cot* sizeof(int*));
	for(int i=0; i<cot; i++) {
		c[i] = (int*)malloc(dong* sizeof(int));
	}
	for(int i=0; i<cot; i++) {
		for(int j=0; j<dong; j++) {
			c[i][j]=b[j][i];
		}
	}
	xuatMang(c,cot,dong);
	int s=1, temp, k=0;
	int x[cot*dong];
	for(int i=0; i<cot; i++) {
		for(int j=0; j<dong; j++) {
			x[k]=c[i][j];
			k++;
		}
	}
	for(int i=0; i<cot*dong; i++) {
		for(int j=i+1; j<cot*dong; j++) {
			if(x[i]<x[j]) {
			   temp=x[i];
			   x[i]=x[j];
			   x[j]=temp;
		}
		}
	}
	printf("Sap xep ma tran C: \n");
	for(int i=0; i<cot*dong; i++) {
		printf("%d ", x[i]);
		if(i==s*dong-1) {
			printf("\n");
			s++;
		}
	}
}
