#include <stdio.h>
#include <stdlib.h>
#include <time.h>
float random(float min, float max) {
	return min + rand() / (float) RAND_MAX * (max-min);
}
int main() {
	float a,b;
	scanf("%f %f", &a,&b);
	int kichThuocA,kichThuocB;
	scanf("%d %d", &kichThuocA,&kichThuocB);
	if(kichThuocA>kichThuocB) {
		printf("Yeu cau nhap lai");
		scanf("%d %d", &kichThuocA,&kichThuocB);
	} // Tao 2 mang A,B
	float A[kichThuocA], B[kichThuocB];
	srand((int)time(0));
	for(int i=0; i<kichThuocA; i++) {
		A[i] = random(a,b);
	}
	for(int i=0; i<kichThuocB; i++) {
		B[i] = random(a,b);
	}
	// Sap xep tang dan
	float x;
	for(int i=0; i<kichThuocA; i++) {
		for(int j=i+1; j<kichThuocA; j++) {
			if(*(A+i)>*(A+j)) {
				x=*(A+i);
				*(A+i)=*(A+j);
				*(A+j)=x;
			}
		}
	}
	for(int i=0; i<kichThuocA; i++) {
		printf("%f ", A[i]);
	}
	printf("\n");
	for(int i=0; i<kichThuocB; i++) {
		for(int j=i+1; j<kichThuocB; j++) {
			if(*(B+i)>*(B+j)) {
				x=*(B+i);
				*(B+i)=*(B+j);
				*(B+j)=x;
			}
		}
	}
	for(int i=0; i<kichThuocB; i++) {
		printf("%f ", B[i]);
	}
	printf("\n");
	// Tron 2 day va sap xep
	float C[kichThuocA + kichThuocB];
	/*for(int i=0; i<kichThuocA+kichThuocB; i++) {
	    if(i<kichThuocA) C[i]=A[i];
	    else C[i]=B[i-kichThuocA];
	}
	for(int i=0; i<kichThuocB+kichThuocA; i++) {
		for(int j=i+1; j<kichThuocB+kichThuocA; j++) {
			if(*(C+i)>*(C+j)) {
				x=*(C+i);
				*(C+i)=*(C+j);
				*(C+j)=x;
			}
		}
	}*/
    for(int i=0; i<kichThuocA; i++) {
    	for(int j=kichThuocB-1; j>=0; j--) {
    		if(*(A+i)<*(B+j)) {
    		   x=*(A+i);
    		   *(A+i)=*(B+j);
    	       *(B+j)=x;
    	    }
    	}
    }
    for(int i=0; i<kichThuocA; i++) {
		for(int j=i+1; j<kichThuocA; j++) {
			if(*(A+i)>*(A+j)) {
				x=*(A+i);
				*(A+i)=*(A+j);
				*(A+j)=x;
			}
		}
	}
	for(int i=0; i<kichThuocB; i++) {
		for(int j=i+1; j<kichThuocB; j++) {
			if(*(B+i)>*(B+j)) {
				x=*(B+i);
				*(B+i)=*(B+j);
				*(B+j)=x;
			}
		}
	}
    for(int i=0; i<kichThuocA+kichThuocB; i++) {
	    if(i<kichThuocB) C[i]=B[i];
	    else C[i]=A[i-kichThuocB];
	}
	for(int i=0; i<kichThuocA+kichThuocB; i++) {
		printf("%f ", C[i]);
	}
	printf("\n");
	float check;
	for(int i=0; i<kichThuocA+kichThuocB; i++) {
		check = C[i] - (int)C[i];
		if(check>=0.5) C[i]=(int)C[i]+1;
		else C[i]=(int)C[i];
	}
	for(int i=0; i<kichThuocA+kichThuocB; i++) {
		printf("%f ", C[i]);
	}
	printf("\n");
	float D[kichThuocA+kichThuocB], E[kichThuocA+kichThuocB];
	for(int i=0; i<kichThuocA+kichThuocB; i++) {
		D[i]=C[i];
		E[i]=C[i];
	}
	for(int i=0; i<kichThuocA+kichThuocB; i++) {
		if((int)D[i]%2!=0) D[i]=-1;
		else if((int)E[i]%2==0) E[i]=-1;
	}
	for(int i=0; i<kichThuocA+kichThuocB; i++) {
		if(D[i]!=-1) printf("%.0f ", D[i]);
	}
	printf("\n");
	for(int i=0; i<kichThuocA+kichThuocB; i++) {
		if(E[i]!=-1) printf("%.0f ", E[i]);
	}
}
