#include <stdio.h>
#include <string.h>
void xoaKiTu(char* a, int x) {
	int s = strlen(a);
	for(int i=x; i<s; i++) {
		a[i]=a[i+1];
	}
	a[s-1]='\0';
}
int main() {
	char a[1000];
	fgets(a,1000,stdin);
	int s = strlen(a);
	while(a[0]==' ') {
		xoaKiTu(a,0);
	}
	for(int i=0; i<s; i++) {
		if(a[i]==' ' && a[i+1]==' ') {
		    xoaKiTu(a,i);
		    i--;
    	}
	}
	while(a[s-1]==' ') {
		xoaKiTu(a,s-1);
	}
	printf("%s", a);
	int soTu=1;
	for(int i=0; i<s; i++) {
		if(a[i]==' ') soTu++;
	}
	printf("soTu la: %d\n", soTu);
	for(int i=0; i<s; i++) {
		if(i==0 || a[i-1]==' ') {
			a[i]=a[i]-32;
		}
	}
	printf("%s", a);
	int viTriThem;
	scanf("%d", &viTriThem);
	//In tung ki tu
	for(int i=0; i<viTriThem; i++) {
		printf("%c", a[i]);
	}
	printf("Toi yeu UET ");
	for(int i=viTriThem; i<s; i++) {
		printf("%c", a[i]);
	}
}
