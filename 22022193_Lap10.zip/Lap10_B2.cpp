#include <stdio.h>
#include <string.h>
#define NUM_DIGITS 100

void tong(char num1[], char num2[], char result[]) {
    int carry = 0; 
    for (int i = NUM_DIGITS - 1; i >= 0; i--) {
        int sum = (num1[i] - '0') + (num2[i] - '0') + carry; 
        result[i] = (sum % 10) + '0'; 
        carry = sum / 10;
    }
}

void hieu(char num1[], char num2[], char result[]) {
    int borrow = 0; 
    for (int i = NUM_DIGITS - 1; i >= 0; i--) {
        int diff = (num1[i] - '0') - (num2[i] - '0') - borrow;
        if (diff < 0) {
            diff += 10;
            borrow = 1;
        } else {
            borrow = 0;
        }
        result[i] = diff + '0';
    }
}

void inRa(char num[]) {
    int i = 0;
    while (num[i] == '0' && i < NUM_DIGITS) { 
        i++;
    }
    if (i == NUM_DIGITS) { 
        printf("0");
    } else {
        while (i < NUM_DIGITS) {
            printf("%c", num[i]);
            i++;
        }
    }
}

int main() {
    char num1[NUM_DIGITS]; 
    char num2[NUM_DIGITS]; 
    char result[NUM_DIGITS];
    printf("Nhap so thu nhat: ");
    scanf("%s", num1);

    printf("Nhap so thu hai: ");
    scanf("%s", num2);

    tong(num1, num2, result);
    printf("Tong la: ");
    inRa(result);
    printf("\n");

    hieu(num1,num2,result);
    printf("Hieu la: ");
    inRa(result);

}
