#include <stdio.h>
#include <stdlib.h>

void inputMatrix(int **matrix, int rows, int cols);
void printMatrix(int **matrix, int rows, int cols);
void multiplyMatrices(int **matrix1, int **matrix2, int **result, int rows1, int cols1, int rows2, int cols2);
void printMainDiagonal(int **matrix, int rows, int cols);
void sortMatrix(int **matrix, int rows, int cols);
void printAs1DArray(int **matrix, int rows, int cols);

int main() {
    int rows1, cols1, rows2, cols2;
    
    printf("Nhap so hang va so cot ma tran A:\n");
    scanf("%d %d", &rows1, &cols1);
    
    int **A = (int **)malloc(rows1 * sizeof(int *));
    for (int i = 0; i < rows1; i++) {
        A[i] = (int *)malloc(cols1 * sizeof(int));
    }
    
    printf("Nhap cac phan tu cua A:\n");
    inputMatrix(A, rows1, cols1);
    printf("Ma tran A:\n");
    printMatrix(A, rows1, cols1);
    
    printf("Nhap so hang va so cot ma tran B:\n");
    scanf("%d %d", &rows2, &cols2);
    
    int **B = (int **)malloc(rows2 * sizeof(int *));
    for (int i = 0; i < rows2; i++) {
        B[i] = (int *)malloc(cols2 * sizeof(int));
    }
    
    printf("Nhap cac phan tu cua B:\n");
    inputMatrix(B, rows2, cols2);
    printf("Ma tran B:\n");
    printMatrix(B, rows2, cols2);
    
    if (cols1 != rows2) {
        printf("Ko the nhan A va B.\n");
        return 0;
    }
    
    int **C = (int **)malloc(rows1 * sizeof(int *));
    for (int i = 0; i < rows1; i++) {
        C[i] = (int *)malloc(cols2 * sizeof(int));
    }
    
    multiplyMatrices(A, B, C, rows1, cols1, rows2, cols2);
    printf("Ma tran C (ket qua A x B):\n");
    printMatrix(C, rows1, cols2);
    
    if (rows2 != cols2) {
        printf("Ma tran B khong vuong, ko the in duong cheo chinh .\n");
    } else {
        printf("Duong cheo chinh cua ma tran B:\n");
        printMainDiagonal(B, rows2, cols2);
    }
    
    printf("Ma tran A giam dan:\n");
    sortMatrix(A, rows1, cols1);
    printMatrix(A, rows1, cols1);
    
    printf("Ma tran A dang 1 chieu:\n");
    printAs1DArray(A, rows1, cols1);
    
    for (int i = 0; i < rows1; i++) {
        free(A[i]);
    }
    free(A);
    for (int i = 0; i < rows2; i++) {
        free(B[i]);
    }
    free(B);
    for (int i = 0; i < rows2; i++) {
        free(C[i]);
    }
    free(C);
    return 0;
}

void inputMatrix(int **matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

void printMatrix(int **matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

void multiplyMatrices(int **matrix1, int **matrix2, int **result, int rows1, int cols1, int rows2, int cols2) {
    for (int i = 0; i < rows1; i++) {
        for (int j = 0; j < cols2; j++) {
            result[i][j] = 0;
            for (int k = 0; k < cols1; k++) {
                result[i][j] += matrix1[i][k] * matrix2[k][j];
            }
        }
    }
}

void printMainDiagonal(int **matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        printf("%d ", matrix[i][i]);
    }
    printf("\n");
}

void sortMatrix(int **matrix, int rows, int cols) {
    int *temp = (int *)malloc(rows * cols * sizeof(int));
    int index = 0;
    for (int j = 0; j < cols; j++) {
        for (int i = 0; i < rows; i++) {
            temp[index++] = matrix[i][j];
        }
    }
    for (int i = 0; i < rows * cols - 1; i++) {
        for (int j = 0; j < rows * cols - i - 1; j++) {
            if (temp[j] < temp[j+1]) {
                int t = temp[j];
                temp[j] = temp[j+1];
                temp[j+1] = t;
            }
        }
    }
    index = 0;
    for (int j = 0; j < cols; j++) {
        for (int i = 0; i < rows; i++) {
            matrix[j][i] = temp[index++];
        }
    }
    free(temp);
}

void printAs1DArray(int **matrix, int rows, int cols) {
    int *temp = (int *)malloc(rows * cols * sizeof(int));
    int index = 0;
    for (int j = 0; j < cols; j++) {
        for (int i = 0; i < rows; i++) {
            temp[index++] = matrix[i][j];
        }
    }
    for (int i = 0; i < rows * cols - 1; i++) {
        for (int j = 0; j < rows * cols - i - 1; j++) {
            if (temp[j] < temp[j+1]) {
                int t = temp[j];
                temp[j] = temp[j+1];
                temp[j+1] = t;
            }
        }
    }
    index = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", temp[index++]);
        }
    }
    printf("\n");
}





