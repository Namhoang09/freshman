#include<stdio.h>
#include<stdlib.h>

void Nhap(double *p, int n) {
	for (int i = 0; i < n; i++) {
		scanf("%lf", &p[i]); 
	} 
} 

void Xuat1(double *p, int n) {
	printf("\nMang theo chieu xuoi la: "); 
	for (int i = 0; i < n; i++) {
		printf("%.2lf ", p[i]); 
	} 
}

void Xuat2(double *p, int n) {
	printf("\nMang theo chieu nguoc la: "); 
	for (int i = n-1; i >=0; i--) {
		printf("%.2lf ", p[i]); 
	} 
}

int demle(double *p, int n){
    int demle = 0;
    for(int i = 0;i<n;i++){
        if((int)p[i] -p[i] == 0){
            if((int)p[i]&1){
                demle++;
            }
        }
    }
    return demle;
}

double tongchan(double *p,int n){
    double tongchan = 0;
    for(int i = 0;i<n;i++){
        if((int)p[i] -p[i] == 0){
            if((int)p[i] % 2 == 0){
               tongchan += p[i];
            }
        }
    }
    return tongchan;
}

int main(){
    double *p;
	int n;    printf("Nhap n: ");    scanf("%d", &n);
	p = (double*)malloc (n*sizeof(double));
	Nhap(p,n);    Xuat1(p,n);    Xuat2(p,n);
    
    
    printf("\n");
    printf("So luong phan tu le trong mang: %i",demle(p,n));

    
    printf("\n");
    printf("Tong so cua cac phan tu chan co trong mang: %.2lf",tongchan(p,n));

    free(p);
    return 0;
}
